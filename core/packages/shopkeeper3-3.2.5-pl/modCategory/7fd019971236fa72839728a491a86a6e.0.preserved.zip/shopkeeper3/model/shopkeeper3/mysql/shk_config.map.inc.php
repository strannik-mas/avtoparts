<?php
$xpdo_meta_map['shk_config']= array (
  'package' => 'shopkeeper3',
  'version' => NULL,
  'table' => 'shopkeeper3_config',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'setting' => '',
    'value' => '',
    'xtype' => '',
  ),
  'fieldMeta' => 
  array (
    'setting' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '15',
      'phptype' => 'string',
      'null' => true,
      'default' => '',
    ),
    'value' => 
    array (
      'dbtype' => 'text',
      'phptype' => 'string',
      'null' => true,
      'default' => '',
    ),
    'xtype' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '15',
      'phptype' => 'string',
      'null' => true,
      'default' => '',
    ),
  ),
);
