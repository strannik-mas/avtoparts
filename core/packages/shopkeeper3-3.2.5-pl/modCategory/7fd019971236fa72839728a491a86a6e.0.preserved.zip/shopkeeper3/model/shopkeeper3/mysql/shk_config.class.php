<?php
require_once (dirname(dirname(__FILE__)) . '/shk_config.class.php');
class shk_config_mysql extends shk_config {}