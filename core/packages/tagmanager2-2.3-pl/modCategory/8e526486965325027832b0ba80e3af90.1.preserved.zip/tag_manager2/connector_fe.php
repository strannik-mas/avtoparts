<?php
/**
 * tagManager2 frontend connector
 *
 * @package tag_manager2
 */

require dirname(dirname(dirname(dirname(__FILE__))))."/config.core.php";
require MODX_CORE_PATH."components/tag_manager2/ajax_resources.php";

?>